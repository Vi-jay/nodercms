{
  "host": "47.96.148.245",
  "port": 27017,
  "db": "admin",
  "user": "root",
  "pass": "123456"
}