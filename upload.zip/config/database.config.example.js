/**
 * MongoDB 数据库配置模板
 */
module.exports = {
  host: '',
  port: '',
  db: '',
  user: '',
  pass: ''
};